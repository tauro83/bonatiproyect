INSERT INTO atencionvacuna(
            precio, nombre, descripcion, fechacaducidad, servicio, hora, 
            fecha, costo)
    VALUES ('6500', 'antiparasitits', 'reduce la vida de parasitos en el organismo', '2009-12-3', 'Policlinico', '15:34', 
            '2009-10-14', '4100');
INSERT INTO atencionvacuna(
            precio, nombre, descripcion, fechacaducidad, servicio, hora, 
            fecha, costo)
    VALUES ('6500', 'antiparasitits', 'reduce la vida de parasitos en el organismo', '2009-12-3', 'Policlinico', '15:34', 
            '2009-10-2', '4100');
INSERT INTO atencionvacuna(
            precio, nombre, descripcion, fechacaducidad, servicio, hora, 
            fecha, costo)
    VALUES ('6500', 'antiparasitits', 'reduce la vida de parasitos en el organismo', '2009-12-3', 'Policlinico', '15:34', 
            '2009-9-20', '4100');
INSERT INTO atencionvacuna(
            precio, nombre, descripcion, fechacaducidad, servicio, hora, 
            fecha, costo)
    VALUES ('6500', 'antiparasitits', 'reduce la vida de parasitos en el organismo', '2009-12-3', 'Policlinico', '15:34', 
            '2009-9-24', '4100');
INSERT INTO atencionvacuna(
            precio, nombre, descripcion, fechacaducidad, servicio, hora, 
            fecha, costo)
    VALUES ('6500', 'antiparasitits', 'reduce la vida de parasitos en el organismo', '2009-12-3', 'Policlinico', '15:34', 
            '2009-9-1', '4100');
INSERT INTO atencionvacuna(
            precio, nombre, descripcion, fechacaducidad, servicio, hora, 
            fecha, costo)
    VALUES ('6500', 'antiparasitits', 'reduce la vida de parasitos en el organismo', '2009-12-3', 'Policlinico', '15:34', 
            '2009-8-20', '4100');
INSERT INTO atencionvacuna(
            precio, nombre, descripcion, fechacaducidad, servicio, hora, 
            fecha, costo)
    VALUES ('6500', 'antiparasitits', 'reduce la vida de parasitos en el organismo', '2009-12-3', 'Policlinico', '15:34', 
            '2009-8-12', '4100');
