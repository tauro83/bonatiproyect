INSERT INTO atencioncontrol(
            descripcion, recomendacion, proximafecha, servicio, hora, fecha, 
            costo)
    VALUES ('visita control de parastios', 'labado semanal', '2009-11-20', 'Policlinico', '20:15', '2009-10-20', 
            '2500');
INSERT INTO atencioncontrol(
            descripcion, recomendacion, proximafecha, servicio, hora, fecha, 
            costo)
    VALUES ('visita control de parastios', 'labado semanal', '2009-11-20', 'Policlinico', '20:15', '2009-10-15', 
            '2500');
INSERT INTO atencioncontrol(
            descripcion, recomendacion, proximafecha, servicio, hora, fecha, 
            costo)
    VALUES ('visita control de parastios', 'labado semanal', '2009-11-20', 'Policlinico', '20:15', '2009-10-4', 
            '2500');
INSERT INTO atencioncontrol(
            descripcion, recomendacion, proximafecha, servicio, hora, fecha, 
            costo)
    VALUES ('visita control de parastios', 'labado semanal', '2009-11-20', 'Policlinico', '20:15', '2009-9-20', 
            '2500');
INSERT INTO atencioncontrol(
            descripcion, recomendacion, proximafecha, servicio, hora, fecha, 
            costo)
    VALUES ('visita control de parastios', 'labado semanal', '2009-11-20', 'Policlinico', '20:15', '2009-9-15', 
            '2500');
INSERT INTO atencioncontrol(
            descripcion, recomendacion, proximafecha, servicio, hora, fecha, 
            costo)
    VALUES ('visita control de parastios', 'labado semanal', '2009-11-20', 'Policlinico', '20:15', '2009-8-20', 
            '2500');
