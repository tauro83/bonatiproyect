INSERT INTO  atencionbanio(rutcliente,nombremascota,servicio,hora,fecha,costo,comentario)
VALUES			  ('16298925'  ,'Larry'	   ,DEFAULT ,'00:30:15','2008-05-01','5600','');

INSERT INTO  atencionbanio(rutcliente,nombremascota,servicio,hora,fecha,costo,comentario)
VALUES			  ('16298923'  ,'Laica'	   ,DEFAULT ,'12:30:15','2009-09-01','9600','');

INSERT INTO  atencionbanio(rutcliente,nombremascota,servicio,hora,fecha,costo,comentario)
VALUES			  ('16298923'  ,'Aguja'	   ,DEFAULT ,'14:30:15','2009-05-01','12600','');

INSERT INTO  atencionbanio(rutcliente,nombremascota,servicio,hora,fecha,costo,comentario)
VALUES			  ('16298923'  ,'Boby'	   ,DEFAULT ,'11:30:15','2008-11-04','2500','');

INSERT INTO  atencionbanio(rutcliente,nombremascota,servicio,hora,fecha,costo,comentario)
VALUES			  ('16298923'  ,'Boby'	   ,DEFAULT ,'08:30:15','2007-06-01','13300','');