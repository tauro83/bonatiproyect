INSERT INTO ClientePresencial(rut,telefono1,telefono2,nombre,correo,estado,domicilioNumero,domicilioComuna,domicilioCalle)
VALUES 	('16298921', '324324','324234','Claudia','claudia@gmail.com','false','234','Talca','Los niches #231');

INSERT INTO ClientePresencial(rut,telefono1,telefono2,nombre,correo,estado,domicilioNumero,domicilioComuna,domicilioCalle)
VALUES 	('16298923', '223324','324234','Sofia','','false','624','Talca','Carrera #11');

INSERT INTO ClientePresencial(rut,telefono1,telefono2,nombre,correo,estado,domicilioNumero,domicilioComuna,domicilioCalle)
VALUES 	('16298925', '244324','32','Alejandro','avergara@hotmail.com','false','134','Talca','Los niches #231');

INSERT INTO ClientePresencial(rut,telefono1,telefono2,nombre,correo,estado,domicilioNumero,domicilioComuna,domicilioCalle)
VALUES 	('16298926', '213278','12','Andrade','claudia@gmail.com','false','234','Curico','Lircay #231');

INSERT INTO ClientePresencial(rut,telefono1,telefono2,nombre,correo,estado,domicilioNumero,domicilioComuna,domicilioCalle)
VALUES 	('16298927', '234354','2','Claudia','claudia@gmail.com','false','234','Talca','Los niches #231');

