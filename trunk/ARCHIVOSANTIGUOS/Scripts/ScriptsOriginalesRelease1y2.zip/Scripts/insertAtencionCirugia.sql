INSERT INTO atencioncirugia(
            estado, diagnostico, tipo, servicio, hora, fecha, costo)
    VALUES (true, 'ninguno', 'no especificado', 'Pabellon', '16:30', '2009-10-12', '14930');
INSERT INTO atencioncirugia(
            estado, diagnostico, tipo, servicio, hora, fecha, costo)
    VALUES (true, 'ninguno', 'no especificado', 'Pabellon', '16:30', '2009-10-10', '14930');

INSERT INTO atencioncirugia(
            estado, diagnostico, tipo, servicio, hora, fecha, costo)
    VALUES (true, 'ninguno', 'no especificado', 'Pabellon', '16:30', '2009-10-5', '14930');

INSERT INTO atencioncirugia(
            estado, diagnostico, tipo, servicio, hora, fecha, costo)
    VALUES (true, 'ninguno', 'no especificado', 'Pabellon', '16:30', '2009-9-12', '14930');

INSERT INTO atencioncirugia(
            estado, diagnostico, tipo, servicio, hora, fecha, costo)
    VALUES (true, 'ninguno', 'no especificado', 'Pabellon', '16:30', '2009-9-25', '14930');

INSERT INTO atencioncirugia(
            estado, diagnostico, tipo, servicio, hora, fecha, costo)
    VALUES (true, 'ninguno', 'no especificado', 'Pabellon', '16:30', '2009-8-12', '14930');

