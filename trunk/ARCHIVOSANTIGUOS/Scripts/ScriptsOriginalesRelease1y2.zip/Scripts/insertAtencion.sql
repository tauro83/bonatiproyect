select * from atencion;


INSERT INTO Atencion (clienteRut,mascotaNombre,servicio,hora,fecha,costo)
VALUES 		('16298923','Larry','Hoteleria','12:52:30','20/10/09','3600');

INSERT INTO Atencion (clienteRut,mascotaNombre,servicio,hora,fecha,costo)
VALUES 		('16298923','Larry','Policlinico I','18:53:30','08/04/09','8200');

INSERT INTO Atencion (clienteRut,mascotaNombre,servicio,hora,fecha,costo)
VALUES 		('16298923','Cachupin','Peluqueria','08:53:30','10/10/09','9500');

INSERT INTO Atencion (clienteRut,mascotaNombre,servicio,hora,fecha,costo)
VALUES 		('16298925','Laica','Policlinico II','13:53:30','07/02/09','12600');

INSERT INTO Atencion (clienteRut,mascotaNombre,servicio,hora,fecha,costo)
VALUES 		('16298923','Larry','Peluqueria','23:53:30','03/03/09','2000');
