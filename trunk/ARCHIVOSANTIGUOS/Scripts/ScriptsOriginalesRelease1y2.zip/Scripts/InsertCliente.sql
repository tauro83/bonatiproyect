INSERT INTO cliente(nombre,apellido,apellido2,rut, rut2,telefono,telefono2,celular,celular2,direccion, region, comuna, email, email2, estado)

VALUES 	('Nicolas','Delgado','Nose','16167986','1','75','987654','09','87654345','alameda 550','Septima', 'Talca', 'nico@mail.com', 'nico2@mail.com', 'TRUE');


INSERT INTO cliente(nombre,apellido,apellido2,rut, rut2,telefono,telefono2,celular,celular2,direccion, region, comuna, email, email2, estado)

VALUES 	('Sebastian','Arancibia','Olguin','16358963','k','75','908098','09','76578921','Los niches Clolihuache 15','Septima', 'Curico', 'seba@mail.com', 'seba2@mail.com', 'TRUE');


INSERT INTO cliente(nombre,apellido,apellido2,rut, rut2,telefono,telefono2,celular,celular2,direccion, region, comuna, email, email2, estado)

VALUES 	('Cristian','Bravo','Rojas','16300000','1','75','9998098','09','765212321','Unimarc','Septima', 'Curico', 'cristian@mail.com', 'Cristian2@mail.com', 'TRUE');

INSERT INTO cliente(nombre,apellido,apellido2,rut, rut2,telefono,telefono2,celular,celular2,direccion, region, comuna, email, email2, estado)

VALUES 	('Camilo','Verdugo','guanthsr','16300999','1','75','9809876','09','765212321','calle 1','Septima', 'Talca', 'camilo@mail.com', 'camilo2@mail.com', 'TRUE');

INSERT INTO cliente(nombre,apellido,apellido2,rut, rut2,telefono,telefono2,celular,celular2,direccion, region, comuna, email, email2, estado)

VALUES 	('Raul','Lopez','raulrich','5166987','1','75','9805556','09','76554543','calle 2','Septima', 'Curico', 'raul@mail.com', 'raul2@mail.com', 'TRUE');
