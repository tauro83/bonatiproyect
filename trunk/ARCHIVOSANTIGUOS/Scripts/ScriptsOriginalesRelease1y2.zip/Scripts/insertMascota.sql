INSERT INTO Mascota (rut,nombre,fechaNacimiento,claseanimal,raza,sexo,estado,imagen)
VALUES 	('16298925', 'Larry2','10/05/2001','Perro','Pastor Aleman','Macho','true','');

INSERT INTO Mascota (rut,nombre,fechaNacimiento,claseanimal,raza,sexo,estado,imagen)
VALUES 	('16298923', 'Aguja','10/05/2001','Perro','Salchicha','Macho','true','');

INSERT INTO Mascota (rut,nombre,fechaNacimiento,claseanimal,raza,sexo,estado,imagen)
VALUES 	('16298923', 'Laica','10/05/2001','Perro','Pastor Aleman','Macho','false','');

INSERT INTO Mascota (rut,nombre,fechaNacimiento,claseanimal,raza,sexo,estado,imagen)
VALUES 	('16298923', 'Boby','10/05/2001','Perro','Kiltro','Macho','true','');

INSERT INTO Mascota (rut,nombre,fechaNacimiento,claseanimal,raza,sexo,estado,imagen)
VALUES 	('16298923', 'patitas','10/05/2001','Perro','Pastor Aleman','Macho','true','');

INSERT INTO Mascota (rut,nombre,fechaNacimiento,sexo,estado, claseanimal, raza)
VALUES 	('16358963', 'Larry','9/9/2004','Macho','true', 'Perro', 'Pastor Aleman');

INSERT INTO Mascota (rut,nombre,fechaNacimiento,sexo,estado, claseanimal, raza)
VALUES 	('16358963', 'Cookie','6/3/2000','Hembra','true', 'Gato', 'Persa');

INSERT INTO Mascota (rut,nombre,fechaNacimiento,sexo,estado, claseanimal, raza)
VALUES 	('16358963', 'Cloky','9/8/1994','Macho','true', 'Perro', 'Puddle');

