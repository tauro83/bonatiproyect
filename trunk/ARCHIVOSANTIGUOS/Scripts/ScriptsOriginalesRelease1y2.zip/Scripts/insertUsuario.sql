INSERT INTO Usuario (nombre,aPaterno,aMaterno,usuario,cargo,contrasena,servicio,pRegistrar,pEditar,pEliminar,pPurgar)
VALUES 		('Claudio', 'Bonati','Perez','cbonati','Veterinario','cbonati','Policlinico I','true','true','true','true');

INSERT INTO Usuario (nombre,aPaterno,aMaterno,usuario,cargo,contrasena,servicio,pRegistrar,pEditar,pEliminar,pPurgar)
VALUES 		('Cristina', 'Cruz','Perez','ccruz','Peluquero','ccruz','Peluqueria','true','true','true','false');

INSERT INTO Usuario (nombre,aPaterno,aMaterno,usuario,cargo,contrasena,servicio,pRegistrar,pEditar,pEliminar,pPurgar)
VALUES		('Felipe', 'Sazo','Saez','fsazo','Ayudante','fsazo','Hoteleria','false','false','false','false');

INSERT INTO Usuario (nombre,aPaterno,aMaterno,usuario,cargo,contrasena,servicio,pRegistrar,pEditar,pEliminar,pPurgar)
VALUES 		('Mauricio', 'Tapia','Ortiz','mtapia','Otro','mtapia','PetShop','true','false','false','false');

INSERT INTO Usuario (nombre,aPaterno,aMaterno,usuario,cargo,contrasena,servicio,pRegistrar,pEditar,pEliminar,pPurgar)
VALUES 		('Alejandra', 'Maraboli','Perez','amaraboli','Secretaria','cbonati','Policlinico I','true','true','false','false');
