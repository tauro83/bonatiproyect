INSERT INTO atencionpostoperatorio(
            medicamentos, alimentos, indicaciones, servicio, hora, fecha, 
            costo, nombremascota, rut, apellido, nombrecliente)
    VALUES ('aspirina', 'agua, alimento', 'reposo', 'Post Operatorio', '15:50', '21/4/2001', 
            '5000', 'Larry', '152348429', 'Gonzales', 'Pedro');

INSERT INTO atencionpostoperatorio(
            medicamentos, alimentos, indicaciones, servicio, hora, fecha, 
            costo, nombremascota, rut, apellido, nombrecliente)
    VALUES ('aspirina', 'agua, alimento', 'reposo', 'Post Operatorio', '16:10', '21/10/2001', 
            '5000', 'Tom', '152348429', 'Gonzales', 'Pedro');

INSERT INTO atencionpostoperatorio(
            medicamentos, alimentos, indicaciones, servicio, hora, fecha, 
            costo, nombremascota, rut, apellido, nombrecliente)
    VALUES ('diazepan', 'carne', 'asdasd', 'Pabellon', '12:56', '2001-05-21', 
            '1000', 'Kaizer', '152348429', 'ramirez', 'Diego');
INSERT INTO atencionpostoperatorio(
            medicamentos, alimentos, indicaciones, servicio, hora, fecha, 
            costo, nombremascota, rut, apellido, nombrecliente)
    VALUES ('diazepan', 'carne', 'asdasd', 'Pabellon', '12:36', '2001-06-21', 
            '1000', 'Kaizer', '152348429', 'ramirez', 'Diego');
INSERT INTO atencionpostoperatorio(
            medicamentos, alimentos, indicaciones, servicio, hora, fecha, 
            costo, nombremascota, rut, apellido, nombrecliente)
    VALUES ('diazepan', 'carne', 'asdasd', 'Pabellon', '12:53', '2001-09-21', 
            '1000', 'Kaizer', '152348429', 'ramirez', 'Diego');
INSERT INTO atencionpostoperatorio(
            medicamentos, alimentos, indicaciones, servicio, hora, fecha, 
            costo, nombremascota, rut, apellido, nombrecliente)
    VALUES ('diazepan', 'carne', 'asdasd', 'Pabellon', '12:09', '2001-10-15', 
            '1000', 'Kaizer', '152348429', 'ramirez', 'Diego');
INSERT INTO atencionpostoperatorio(
            medicamentos, alimentos, indicaciones, servicio, hora, fecha, 
            costo, nombremascota, rut, apellido, nombrecliente)
    VALUES ('diazepan', 'carne', 'asdasd', 'Pabellon', '12:01', '2001-10-05', 
            '1000', 'Kaizer', '152348429', 'ramirez', 'Diego');