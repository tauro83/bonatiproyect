INSERT INTO atencionconsulta(
            anamnesis, servicio, hora, fecha, costo)
    VALUES ('Primera inyeccion', 'Policlinico', '15:36', '2009-10-20', '5000');
INSERT INTO atencionconsulta(
            anamnesis, servicio, hora, fecha, costo)
    VALUES ('control mensual de octubre', 'Policlinico', '15:36', '2009-10-5', '5000');

INSERT INTO atencionconsulta(
            anamnesis, servicio, hora, fecha, costo)
    VALUES ('Primera inyeccion', 'Policlinico', '15:36', '2009-10-15', '5000');

INSERT INTO atencionconsulta(
            anamnesis, servicio, hora, fecha, costo)
    VALUES ('Primera inyeccion', 'Policlinico', '15:36', '2009-9-20', '5000');

INSERT INTO atencionconsulta(
            anamnesis, servicio, hora, fecha, costo)
    VALUES ('Primera inyeccion', 'Policlinico', '15:36', '2009-9-28', '5000');

INSERT INTO atencionconsulta(
            anamnesis, servicio, hora, fecha, costo)
    VALUES ('Primera inyeccion', 'Policlinico', '15:36', '2009-9-1', '5000');

INSERT INTO atencionconsulta(
            anamnesis, servicio, hora, fecha, costo)
    VALUES ('Primera inyeccion', 'Policlinico', '15:36', '2009-8-20', '5000');
