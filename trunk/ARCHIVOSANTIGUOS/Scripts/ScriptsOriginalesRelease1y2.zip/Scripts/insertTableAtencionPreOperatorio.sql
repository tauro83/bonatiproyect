INSERT INTO atencionpreoperatorio(
            observaciones, sintomas, diagnosticos, servicio, hora, fecha, 
            costo)
    VALUES ('pierna rota', 'ninguno', 'asdasd', 'asdasd', '12:56', '2001-05-21', 
            '1000');
INSERT INTO atencionpreoperatorio(
            observaciones, sintomas, diagnosticos, servicio, hora, fecha, 
            costo)
    VALUES ('pierna rota', 'ninguno', 'asdasd', 'asdasd', '12:36', '2001-06-21', 
            '1000');
INSERT INTO atencionpreoperatorio(
            observaciones, sintomas, diagnosticos, servicio, hora, fecha, 
            costo)
    VALUES ('pierna rota', 'ninguno', 'asdasd', 'asdasd', '12:53', '2001-09-21', 
            '1000');
INSERT INTO atencionpreoperatorio(
            observaciones, sintomas, diagnosticos, servicio, hora, fecha, 
            costo)
    VALUES ('pierna rota', 'ninguno', 'asdasd', 'asdasd', '12:09', '2001-10-15', 
            '1000');
INSERT INTO atencionpreoperatorio(
            observaciones, sintomas, diagnosticos, servicio, hora, fecha, 
            costo)
    VALUES ('pierna rota', 'ninguno', 'asdasd', 'asdasd', '12:01', '2001-10-05', 
            '1000');