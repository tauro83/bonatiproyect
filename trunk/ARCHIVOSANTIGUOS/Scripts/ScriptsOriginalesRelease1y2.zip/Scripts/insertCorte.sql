INSERT INTO  corte(rutcliente,nombremascota,servicio,hora,	foto ,fecha	  ,raza		,costo	,nombre ,categoria		,descripcion)
VALUES		  ('16298925'  ,'Larry'	   ,DEFAULT ,'08:30:15',''   ,'2007-06-01','Pastor'	,'13300',''	,'Corte tradicional'    ,'');

INSERT INTO  corte(rutcliente,nombremascota,servicio,hora,	foto ,fecha	  ,raza		,costo	,nombre ,categoria		,descripcion)
VALUES		  ('16298923','Boby'	   ,DEFAULT ,'18:40:12',''   ,'2008-06-05','Pastor'	,'2200',''	,'Tradicional'    ,'');

INSERT INTO  corte(rutcliente,nombremascota,servicio,hora,	foto ,fecha	  ,raza		,costo	,nombre ,categoria		,descripcion)
VALUES		  ('16298923','Aguja'	   ,DEFAULT ,'13:30:10',''   ,'2009-03-03','Pastor'	,'5300',''	,'Corte tradicional'    ,'');

INSERT INTO  corte(rutcliente,nombremascota,servicio,hora,	foto ,fecha	  ,raza		,costo	,nombre ,categoria		,descripcion)
VALUES		  ('16298923','Boby'	   ,DEFAULT ,'10:30:13',''   ,'2002-05-02','Pastor'	,'5600',''	,'Corte tradicional'    ,'');

INSERT INTO  corte(rutcliente,nombremascota,servicio,hora,	foto ,fecha	  ,raza		,costo	,nombre ,categoria		,descripcion)
VALUES		  ('16298923','Boby'	   ,DEFAULT ,'20:30:35',''   ,'2009-01-01','Pastor'	,'8500',''	,'Corte tradicional'    ,'');




INSERT INTO  postoperatorio(observaciones, sintomas, diagnostico, servicio, hora, fecha ,rut, nombremascota	, raza, sexo, nombre, apellidopaterno, alimento, medicamento, indicaciones, estado)
VALUES ('observaciones de la mascota', 'Sintomas de la mascota', 'diagn�stico de la mascota', 'cl�nica', '12:30' ,'2009-06-05', '12340006'	,'Doki','pastor collie', 'hembra', 'Carlos', 'Fernandez', '','medicamento', 'indicaciones a la mascota', 'FALSE');

INSERT INTO  postoperatorio(observaciones, sintomas, diagnostico, servicio, hora, fecha ,rut, nombremascota	, raza, sexo, nombre, apellidopaterno, alimento, medicamento, indicaciones, estado)
VALUES ('observaciones de la mascota2', 'Sintomas de la mascota2', 'diagn�stico de la mascota2', 'cl�nica', '13:30' ,'2009-06-05', '12340006'	,'Lola','pastor collie', 'hembra', 'Catalina', 'Gutierrez', '','medicamento2', 'indicaciones a la mascota2', 'FALSE');

INSERT INTO  postoperatorio(observaciones, sintomas, diagnostico, servicio, hora, fecha ,rut, nombremascota	, raza, sexo, nombre, apellidopaterno, alimento, medicamento, indicaciones, estado)
VALUES ('observaciones de la mascota3', 'Sintomas de la mascota3', 'diagn�stico de la mascota3', 'cl�nica', '14:30' ,'2009-06-05', '12340006'	,'lassie','pastor collie', 'hembra', 'Gonzalo', 'Higuah�n', '','medicamento3', 'indicaciones a la mascota2', 'FALSE');

