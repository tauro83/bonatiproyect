INSERT INTO  atencionpedicure(rutcliente,nombremascota,servicio,hora	,fecha	  	,costo	,descripcion		, nombre)
VALUES		  ('16298923','Boby'	   ,DEFAULT ,'20:30:35' ,'2009-01-01'	,'8500','Corte y limpieza'	,'Corte de u�as');

INSERT INTO  atencionpedicure(rutcliente,nombremascota,servicio,hora	,fecha	  	,costo	,descripcion		, nombre)
VALUES		  ('16298925'  ,'Larry'	   ,DEFAULT ,'10:20:31' ,'2009-06-02'	,'6000','Corte y limpieza'	,' ');

INSERT INTO  atencionpedicure(rutcliente,nombremascota,servicio,hora	,fecha	  	,costo	,descripcion		, nombre)
VALUES		  ('16298923','Boby'	   ,DEFAULT ,'15:30:35' ,'2008-01-08'	,'3210','Corte y limpieza'	,' ');

INSERT INTO  atencionpedicure(rutcliente,nombremascota,servicio,hora	,fecha	  	,costo	,descripcion		, nombre)
VALUES		  ('16298925'  ,'Larry'	   ,DEFAULT ,'18:30:35' ,'2009-06-01'	,'6500','Corte y limpieza'	,' ');

INSERT INTO  atencionpedicure(rutcliente,nombremascota,servicio,hora	,fecha	  	,costo	,descripcion		, nombre)
VALUES		  ('16298923','Boby'	   ,DEFAULT ,'03:30:35' ,'2002-01-01'	,'8500','Corte y limpieza'	,'Corte de u�as');